using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace nbd.sub_classes;

/// <summary>
/// Modèle de simulation complet (grains, comportements, champs)
/// </summary>
public class GrainModel
{
    [JsonPropertyName("name")] public string Name { get; set; } = "";
    [JsonPropertyName("description")] public string Description { get; set; } = "";
    [JsonPropertyName("grains")] public List<Grain> Grains { get; set; } = new();
    [JsonPropertyName("behaviours")] public List<Behaviour> Behaviours { get; set; } = new();
    [JsonPropertyName("fields")] public List<Field> Fields { get; set; } = new();

    public GrainModel() { }

    public GrainModel(string name, string description, List<Grain> grains, List<Behaviour> behaviours, List<Field> fields)
    {
        Name = name;
        Description = description;
        Grains = grains;
        Behaviours = behaviours;
        Fields = fields;
    }

    public Grain? GrainForId(int id)
    {
        return Grains.Find(g => g.Id == id);
    }

    public Field? FieldForId(int id)
    {
        return Fields.Find(f => f.Id == id);
    }

    public bool HasField(int id)
    {
        return Fields.Exists(f => f.Id == id);
    }
}
